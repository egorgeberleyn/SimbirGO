﻿using Simbir.GO.Domain.Accounts;
using Simbir.GO.Shared.Persistence.Repositories;

namespace Simbir.GO.Application.Interfaces.Persistence.Repositories;

public interface IAccountRepository : IRepository<Account>
{
}