﻿namespace Simbir.GO.Domain.Transports.Enums;

public enum TransportType
{
    None = 0,
    Car = 1,
    Bike = 2,
    Scooter = 3,
    All = 4,
}