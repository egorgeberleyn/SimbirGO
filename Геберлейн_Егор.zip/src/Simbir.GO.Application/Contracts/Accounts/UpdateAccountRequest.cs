﻿namespace Simbir.GO.Application.Contracts.Accounts;

public record UpdateAccountRequest(
    string Username, 
    string Password);
