﻿namespace Simbir.GO.Application.Contracts.Accounts;

public record SignUpAccountRequest(
    string Username, 
    string Password);