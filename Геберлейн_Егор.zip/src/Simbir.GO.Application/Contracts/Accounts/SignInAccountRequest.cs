﻿namespace Simbir.GO.Application.Contracts.Accounts;

public record SignInAccountRequest(
    string Username, 
    string Password);
