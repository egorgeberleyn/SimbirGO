﻿using Simbir.GO.Domain.Rents;
using Simbir.GO.Shared.Persistence.Repositories;

namespace Simbir.GO.Application.Interfaces.Persistence.Repositories;

public interface IRentRepository : IRepository<Rent>
{
    
}