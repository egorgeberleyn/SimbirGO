﻿namespace Simbir.GO.Application.Services.Common;

public record AuthResult(string AccessToken);