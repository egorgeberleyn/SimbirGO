﻿using Simbir.GO.Domain.Transports;
using Simbir.GO.Shared.Persistence.Repositories;

namespace Simbir.GO.Application.Interfaces.Persistence.Repositories;

public interface ITransportRepository : IRepository<Transport>
{
}