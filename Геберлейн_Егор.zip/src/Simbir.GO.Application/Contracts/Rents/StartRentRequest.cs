﻿namespace Simbir.GO.Application.Contracts.Rents;

public record StartRentRequest(string RentType);