﻿namespace Simbir.GO.Application.Contracts.Admin.Rents;

public record AdminEndRentRequest(
    double Lat, 
    double Long);