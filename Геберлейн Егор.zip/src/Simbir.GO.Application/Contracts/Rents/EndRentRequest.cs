﻿namespace Simbir.GO.Application.Contracts.Rents;

public record EndRentRequest(
    double Lat, 
    double Long);
