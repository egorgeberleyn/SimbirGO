﻿namespace Simbir.GO.Domain.Rents.Enums;

public enum PriceType
{
    None = 0,
    Minutes = 1,
    Days = 2,
}